#ifndef POWERUP_HPP
#define POWERUP_HPP

#include <SFML/Graphics.hpp>
#include <SFML/System/Clock.hpp>

// les types de power-ups
enum class PowerUpType {
    SpeedBoost,     // augmente la vitesse tmp
    SlowMotion,     // ralentit le serpent
    ScoreMultiplier,// multiplie le score gagn� par fruit tmp
    Invincibility   // rend le serpent invincible aux obstacles/corps

};

class PowerUp {
public:
    PowerUp(int gridSize, PowerUpType type);

    void draw(sf::RenderWindow& window) const;
    void setPosition(sf::Vector2i position);
    sf::Vector2i getPosition() const;
    PowerUpType getType() const;

    // pour les power-ups tmp
    bool isActive() const;
    void activate(float duration);
    void update(float deltaTime);
    float getRemainingTime() const;

private:
    sf::Vector2i position;
    int gridSize;
    PowerUpType type;
    sf::Color color;
    sf::CircleShape shape; // forme

    // gestion de dur�e
    bool active;
    float duration;
    sf::Clock timer;
};

#endif
