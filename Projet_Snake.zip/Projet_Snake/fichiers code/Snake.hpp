#ifndef SNAKE_HPP
#define SNAKE_HPP

#include <SFML/Graphics.hpp>
#include <vector>

// les directions du serpent
enum class Direction {
    Up,
    Down,
    Left,
    Right
};

class Snake {
public:
    Snake(int gridSize);

    void move();
    void grow();
    void draw(sf::RenderWindow& window) const;
    void setDirection(Direction newDirection);
    bool checkSelfCollision() const;

    sf::Vector2i getHeadPosition() const;
    void updateHeadPosition(sf::Vector2i newPosition);
    std::vector<sf::Vector2i> getBodyPositions() const;
    void setInvincible(bool invincible); // pour l'effet visuel

private:
    std::vector<sf::Vector2i> body;
    Direction direction;
    Direction lastMoveDirection;
    bool shouldGrow;
    int gridSize;
    sf::Color headColor;
    sf::Color bodyColor;
    bool isInvincible;
};

#endif
