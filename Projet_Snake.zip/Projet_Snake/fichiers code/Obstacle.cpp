#include "Obstacle.hpp"

Obstacle::Obstacle(int gridSize) :
    gridSize(gridSize),
    color(sf::Color(150, 75, 0)) // marron
{
    position = sf::Vector2i(0, 0);
}

void Obstacle::draw(sf::RenderWindow& window) const
{
    // dessine l'obstacle
    sf::RectangleShape shape(sf::Vector2f(gridSize - 1, gridSize - 1));
    shape.setFillColor(color);
    shape.setPosition(position.x * gridSize, position.y * gridSize);
    window.draw(shape);
}

void Obstacle::setPosition(sf::Vector2i newPosition)
{
    position = newPosition;
}

sf::Vector2i Obstacle::getPosition() const
{
    return position;
}
