#include "PowerUp.hpp"
#include <cstdlib>

PowerUp::PowerUp(int gridSize, PowerUpType type) :
    gridSize(gridSize),
    type(type),
    active(false),
    duration(0.0f)
{
    // couleur en fct du type
    switch (type)
    {
    case PowerUpType::SpeedBoost:
        color = sf::Color::Yellow;
        break;
    case PowerUpType::SlowMotion:
        color = sf::Color::Cyan;
        break;
    case PowerUpType::ScoreMultiplier:
        color = sf::Color::Magenta;
        break;
    case PowerUpType::Invincibility:
        color = sf::Color::White;
        break;
    default:
        color = sf::Color::Green; // couleur par d�faut
        break;
    }

    // Cercle visuel petit
    shape.setRadius(gridSize / 2.5f);
    shape.setFillColor(color);
    shape.setOutlineColor(sf::Color::Black);
    shape.setOutlineThickness(1);

    sf::FloatRect bounds = shape.getLocalBounds();
    shape.setOrigin(bounds.left + bounds.width / 2.0f, bounds.top + bounds.height / 2.0f);
}

void PowerUp::draw(sf::RenderWindow& window) const
{
    window.draw(shape);
}

void PowerUp::setPosition(sf::Vector2i newPosition)
{
    position = newPosition;
    // M�j la position de la forme graphique
    shape.setPosition(position.x * gridSize + gridSize / 2.0f, position.y * gridSize + gridSize / 2.0f);
}

sf::Vector2i PowerUp::getPosition() const
{
    return position;
}

PowerUpType PowerUp::getType() const
{
    return type;
}

// --- m�thodes pour les power-ups temporaires ---

bool PowerUp::isActive() const
{
    return active;
}

void PowerUp::activate(float effectDuration)
{
    active = true;
    duration = effectDuration;
    timer.restart(); // chronom�tre
}

void PowerUp::update(float deltaTime)
{
    if (active)
    {
        if (timer.getElapsedTime().asSeconds() >= duration)
        {
            active = false;
            duration = 0.0f;
        }
    }
}

float PowerUp::getRemainingTime() const
{
    if (!active)
        return 0.0f;

    float elapsed = timer.getElapsedTime().asSeconds();
    return std::max(0.0f, duration - elapsed);
}
