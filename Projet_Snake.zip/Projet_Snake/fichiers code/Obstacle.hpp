#ifndef OBSTACLE_HPP
#define OBSTACLE_HPP

#include <SFML/Graphics.hpp>

class Obstacle {
public:
    Obstacle(int gridSize);

    void draw(sf::RenderWindow& window) const;
    void setPosition(sf::Vector2i position);
    sf::Vector2i getPosition() const;

private:
    sf::Vector2i position;
    int gridSize;
    sf::Color color;
};

#endif 
