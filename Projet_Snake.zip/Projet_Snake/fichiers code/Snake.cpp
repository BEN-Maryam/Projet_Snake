#include "Snake.hpp"

Snake::Snake(int gridSize) :
    direction(Direction::Right),
    lastMoveDirection(Direction::Right),
    shouldGrow(false),
    gridSize(gridSize),
    headColor(sf::Color::Blue),
    bodyColor(sf::Color(0, 0, 200)),
    isInvincible(false)
{
    // le serpent
    int startX = 10;
    int startY = 10;

    // les segments du corps
    body.push_back(sf::Vector2i(startX, startY));       // t�te
    body.push_back(sf::Vector2i(startX - 1, startY));   // corps
    body.push_back(sf::Vector2i(startX - 2, startY));   // queue
}

void Snake::move()
{
    lastMoveDirection = direction;

    if (!shouldGrow)
    {
        body.pop_back();
    }
    else
    {
        shouldGrow = false;
    }

    sf::Vector2i head = body.front();

    // calcul la nouvelle position de la t�te
    switch (direction)
    {
    case Direction::Up:
        head.y--;
        break;
    case Direction::Down:
        head.y++;
        break;
    case Direction::Left:
        head.x--;
        break;
    case Direction::Right:
        head.x++;
        break;
    }

    // ajoute la nouvelle t�te au d�but du corps
    body.insert(body.begin(), head);
}

void Snake::grow()
{
    shouldGrow = true;
}

void Snake::draw(sf::RenderWindow& window) const
{
    // dessine le serpent
    for (size_t i = 0; i < body.size(); i++)
    {
        sf::RectangleShape segment(sf::Vector2f(gridSize - 1, gridSize - 1));

        sf::Color currentHeadColor = headColor;
        sf::Color currentBodyColor = bodyColor;

        // effet visuel pour l'invincibilit�
        if (isInvincible) {
            currentHeadColor.a = 100;
            currentBodyColor.a = 200;
        }

        if (i == 0)
        {
            segment.setFillColor(currentHeadColor);
        }
        else
        {
            segment.setFillColor(currentBodyColor);
        }

        segment.setPosition(body[i].x * gridSize, body[i].y * gridSize);
        window.draw(segment);
    }
}

void Snake::setDirection(Direction newDirection)
{
    if ((newDirection == Direction::Up && lastMoveDirection != Direction::Down) ||
        (newDirection == Direction::Down && lastMoveDirection != Direction::Up) ||
        (newDirection == Direction::Left && lastMoveDirection != Direction::Right) ||
        (newDirection == Direction::Right && lastMoveDirection != Direction::Left))
    {
        direction = newDirection;
    }
}

bool Snake::checkSelfCollision() const
{
    sf::Vector2i head = body.front();

    for (size_t i = 1; i < body.size(); i++)
    {
        if (body[i] == head)
        {
            return true;
        }
    }

    return false;
}

sf::Vector2i Snake::getHeadPosition() const
{
    return body.front();
}

void Snake::updateHeadPosition(sf::Vector2i newPosition)
{
    // M�j position de la t�te
    body[0] = newPosition;
}

std::vector<sf::Vector2i> Snake::getBodyPositions() const
{
    return body;
}

void Snake::setInvincible(bool invincible) {
    isInvincible = invincible;
}
