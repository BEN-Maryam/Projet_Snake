#include "Fruit.hpp"

Fruit::Fruit(int gridSize) :
    gridSize(gridSize),
    color(sf::Color::Red)
{
    // position
    position = sf::Vector2i(0, 0);
}

void Fruit::draw(sf::RenderWindow& window) const
{
    // dessine le fruit
    sf::CircleShape shape(gridSize / 2.0f);
    shape.setFillColor(color);
    shape.setPosition(position.x * gridSize, position.y * gridSize);
    window.draw(shape);
}

void Fruit::setPosition(sf::Vector2i newPosition)
{
    position = newPosition;
}

sf::Vector2i Fruit::getPosition() const
{
    return position;
}
