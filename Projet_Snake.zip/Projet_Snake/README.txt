
**Projet Snake - Mini Projet C++**


Jeu vidéo Snake développé en C++ avec la bibliothèque SFML.

### Fonctionnalités principales :

* Serpent (bleu) qui grandit en mangeant des fruits (rouge) générés aléatoirement.
* Murs traversables : le serpent ressort de l'autre côté de l'écran.
* Détection de collision avec le corps du serpent et avec des obstacles (Game Over).
* À chaque fruit mangé, 2 obstacles aléatoires apparaissent.
* Affichage du score en temps réel.
* Sauvegarde et affichage des 5 meilleurs scores.
* Effets sonores pour manger un fruit, prendre un power-up et game over.
* Power-ups spéciaux avec effets temporaires :

  * Vitesse+ (jaune)
  * Ralenti (cyan)
  * Score x3 (magenta)
  * Invincibilité (blanc)
